
botao=document.querySelector(".nao_autorizado");
botao.addEventListener("click",()=>impossivel());
function impossivel(){    
    window.alert("Para prosseguir é necessário ser maior de idade !");
};
